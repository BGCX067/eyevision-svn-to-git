using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AnalysisTool
{
    //Provides the base for the DoubleBufferReplayControl. 
    // Author: Smitha Madhavamurthy
    // Date: 04-15-2007

    
    public partial class ReplayGraphics : Form
    {
        public ReplayGraphics()
        {
            InitializeComponent();
        }
    }
}